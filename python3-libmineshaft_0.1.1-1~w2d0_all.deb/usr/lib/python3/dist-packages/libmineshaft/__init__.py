import pygame

__version__ = "0.1.1"
__author__ = "Double Fractal Game Studios"
__credits__  = '''Double Fractal Game Studios team:
Mayu Sakurai
Alexey Pavlov
'''
