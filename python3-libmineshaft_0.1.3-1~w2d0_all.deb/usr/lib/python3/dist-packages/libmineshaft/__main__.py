print("libmineshaft does not provide the interactive Mineshaft shell at this version ")
