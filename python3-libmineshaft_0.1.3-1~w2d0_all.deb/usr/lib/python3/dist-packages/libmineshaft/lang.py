def respond(response):
    raise NotImplementedError()
