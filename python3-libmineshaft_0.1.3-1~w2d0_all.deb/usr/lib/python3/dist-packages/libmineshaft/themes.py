from pygame_menu import *
from pygame_menu.widgets import *


MINESHAFT_DEFAULT_THEME = Theme(
    background_color=(0, 0, 0, 0),  # transparent background
    title_background_color=(4, 47, 126),
    title_font_shadow=True,
    widget_padding=25,
    title_bar_style=MENUBAR_STYLE_NONE,
)
