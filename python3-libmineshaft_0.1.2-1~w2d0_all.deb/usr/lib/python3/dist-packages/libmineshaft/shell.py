import .lang
def run():
    while True:
        response = input("Mineshaft~$")
        lang.respond(response)
