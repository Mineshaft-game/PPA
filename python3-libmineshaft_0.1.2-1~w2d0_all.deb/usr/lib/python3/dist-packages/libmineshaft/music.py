import os
import pygame
pygame.mixer.init()


MENU1 = pygame.mixer.Sound("assets/audio/music/menu1.ogg")