"""A collection of modules containing control-style widgets and popups, like sliders and gauges
"""

import py_cui.controls.slider