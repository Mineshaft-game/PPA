"""A collection of modules containing dialog-style widgets and popups.
"""

import py_cui.dialogs.form
import py_cui.dialogs.filedialog