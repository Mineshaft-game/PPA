class World:
    def __init__(self, world=None, name="World", gamemode=0):
        """The currently-useless world class"""
        self.gamemode = gamemode
        self.world = world
        self.name = name
