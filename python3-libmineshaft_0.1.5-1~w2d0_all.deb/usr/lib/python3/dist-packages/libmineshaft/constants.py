HEIGHT = 600
WIDTH = 800
NAME = "Mineshaft"
