import os

os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"
import pygame


__version__ = "0.1.5"
__author__ = "Double Fractal Game Studios"
__credits__ = """Double Fractal Game Studios team:
Mayu Sakurai
Alexey Pavlov
"""
