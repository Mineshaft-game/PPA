from . import shell


if __name__ == "__main__":
    shell.run()
