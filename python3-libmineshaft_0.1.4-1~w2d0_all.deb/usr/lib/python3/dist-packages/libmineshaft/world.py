class World:
    def __init__(self, world=None, name="World", gamemode=0):
        self.gamemode = gamemode
        self.world = world
        self.name = name
